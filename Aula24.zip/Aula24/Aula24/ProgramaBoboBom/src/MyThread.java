/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JTextField;
/**
 *
 * @author Mauricio
 */
public class MyThread extends Thread {
   private JTextField    tf1;
   private int k;
   private boolean flag;

    MyThread(JTextField _txtField, int _k, boolean _flag) 
    {
        tf1=_txtField;
        k = _k;
        flag = _flag;
    }
    public void setFlag(boolean _flag) {flag = _flag;}
    
    public void run()
    {
        while (flag == true)
        {
            tf1.setText("" + k);
            ++k;
            try { Thread.sleep(1000); } catch(Exception e) {}
        }
    }
    
}
