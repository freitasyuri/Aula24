/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.DefaultListModel;
import javax.swing.JList;


/**
 *
 * @author Mauricio
 */
public class MyThread2 extends Thread {
    private DefaultListModel modelo; 
    private JList lista;

    MyThread2(DefaultListModel _modelo, JList _lista) 
    {
       modelo = _modelo;
       lista = _lista;
       lista.setModel(modelo);
    }
    
    public void run()
    {
        try
        {
            ServerSocket server = new ServerSocket(9060);
            Socket cliente = server.accept();         
            Scanner receber = new Scanner(cliente.getInputStream());
            modelo.addElement("vai começar...");
            while (receber.hasNextLine())
            {
                modelo.addElement(receber.nextLine());
            }

            receber.close();
            server.close();
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "ERRO: " + e.getMessage());
        }
    }
    
}
